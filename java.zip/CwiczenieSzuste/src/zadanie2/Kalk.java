package zadanie2;

import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import java.awt.*;

public class Kalk implements ActionListener, KeyListener
{
   JTextField t1;
   JButton b1, b2, b3, b4, b5, b6, b7, b8, b9, b0;
   JButton bplus, bminus, bmultiple, bdivide, brow, bdot, bclear;
   JButton potegowanie, pierwiastek, procent, back;
   
   double x = 0.0, buf;
   String s = "";
   JButton[] button = {b1, b2, b3, b4, b5, b6, b7, b8, b9, b0};
   JButton[] buttonSign = {bplus, bminus, bmultiple, bdivide, brow}; 
   JButton[] buttonSign2 = {potegowanie, pierwiastek, procent, back}; 
   
   ArrayList <Double> backup = new <Double> ArrayList();
   static int backInt = 2;
   
   public void keyPressed(KeyEvent e) { }
   public void keyReleased(KeyEvent e) { }
   public void keyTyped(KeyEvent e) {
	   if ( !( (e.getKeyChar() >= (int)'0') && (e.getKeyChar() <= (int)'9') || ("+-*/^3%.=".contains("" + e.getKeyChar())))){
		   JFrame alert=new JFrame(); 
	    	  JOptionPane.showMessageDialog(alert,
	    			    "Niepoprawne dane z klawiatury");     
	    	  e.consume();
	   }
   }
   
   public void actionPerformed(ActionEvent e)                  
   {      
    Object target = e.getSource(); 
	        
	    for (int i = 0; i < 10; i++){
		    if(target==button[i])                                           
		    { 
		    	String temp = t1.getText() + Integer.toString((i+1)%10);
		    	t1.setText(temp);
		        t1.requestFocus(); 
		        continue;
		    }        
	    }
	         
		if(target==buttonSign[0])                                           
		{ 
			String temp = (t1.getText() + " + ");
			t1.setText(temp);
		    t1.requestFocus();                                  
		}   
	
		if(target==buttonSign[1])                                           
		{ 
			String temp = (t1.getText() + " - ");
			t1.setText(temp);
		    t1.requestFocus();                                   
		}   
		  
		if(target==buttonSign[2])                                           
		{ 
			String temp = (t1.getText() + " * ");
			t1.setText(temp);
		    t1.requestFocus();                                   
		}   
		  
		if(target==buttonSign[3])                                           
		{ 
			String temp = (t1.getText() + " / ");
			t1.setText(temp);
		    t1.requestFocus();                                
		}   
		  
		if(target==buttonSign2[0])                                           
		{ 
			String temp = (t1.getText() + " ^ ");
			t1.setText(temp);
		    t1.requestFocus();                                  
		}
		  
		if(target==buttonSign2[1])                                           
		{ 
			String temp = (t1.getText() + " # ");
			t1.setText(temp);
		    t1.requestFocus();                                  
		}
		  
		if(target==buttonSign2[2])                                           
		{ 
			String temp = (t1.getText() + " % ");
			t1.setText(temp);
		    t1.requestFocus();                                  
		}
		  
		if(target==buttonSign2[3])                                           
		{ 
			try{
				BufferedReader plik2=new BufferedReader(new FileReader("RezultatyObliczen.txt"));                    
			    String str; 
			                                                                                                 
			    while(plik2.ready())                                                                    
			    {    
			        str=plik2.readLine();  
			       	backup.add(Double.parseDouble(str));                                                            
			    } 
			    double b = backup.get(backup.size()-backInt);
			    backInt++;
			    System.out.println("cofnieta operacja " + b); 
			    plik2.close();
			      
				String temp = (String.valueOf(b));
				t1.setText(temp);
			    t1.requestFocus();    
			}
			catch (IOException ex){
				ex.printStackTrace();
			}
		  
		} 
		if(target==bdot)                                           
		{  
			String str = t1.getText();
			String temp = str + ".";
			for (int i = str.length() - 1; i >= 0; i--){
				if ( "+-*/ ".contains(Character.toString(str.charAt(i)))	)	break;
				else if (".".contains(Character.toString(str.charAt(i)))	){
					temp = "Error";
				}
			}
			t1.setText(temp);
		    t1.requestFocus();                                 
		}
		  
		if(target==brow)                                           
		{ 
			try {
		    	File file = new File("RezultatyObliczen.txt");
		    	file.delete();
		    	PrintWriter plik1=new PrintWriter(new BufferedWriter(new FileWriter("RezultatyObliczen.txt",true))); 
			      
		    	String sign = "";
		    	boolean xEmpty = true;
		    	boolean isAhead = false;
			  
		    	int startNumber = 0;
			  	int endNumber = 0;
			  	boolean isBegin = false;
			  
			  	String str = t1.getText() + " ";
			  	System.out.println(str);
			  
			  	for (int i = 0; i < str.length(); i++){
			  		String current = str.substring(i, i+1);
			  		if ( (((int)current.charAt(0) >= (int)'0') && ((int)current.charAt(0) <= (int)'9')) || current.contains(".") ){
			  			if ( !(isBegin) ){
			  				startNumber = i;
							isBegin = true;
						}
						  endNumber = i;
					}
					else{
						if ( isBegin ){
							buf = Double.parseDouble(str.substring(startNumber, endNumber+1));
							isBegin = false;
						  
							if (xEmpty){
								if (isAhead){
									if (sign.equals("-"))	buf *= -1;
									if (sign.equals("#"))	buf = Math.sqrt(buf);
								}
								x = buf;
								xEmpty = false;
							}
							else{
								if (sign.contains("+"))	x += buf;
								if (sign.contains("-"))	x -= buf;
								if (sign.contains("*"))	x *= buf;
								if (sign.contains("/")){
									if (buf != 0)	x /= buf;
								}
								if (sign.contains("^"))	x = Math.pow( x , buf );
								System.out.println(x);
							    plik1.println(x);
								  
							}
						}
					  
						if ("+-/*^#%".contains(current)){
							System.out.println(sign);
							sign = current;
						}
						  
						if ("#%".contains(current)) {
							if (sign.contains("#")){
								if (x >= 0)	x = Math.sqrt( x );
							}
							if (sign.contains("%"))	x /= 100;
							System.out.println(x);
						    plik1.println(x);
						}
						  
						if ( (xEmpty) && "-#".contains(sign) ){
							isAhead = true;
						}
					} 
				}  
			  	plik1.close();
				}
			    catch (IOException ex){
			    	ex.printStackTrace();
			    }
				  
				  
				t1.setText(Double.toString(x));
			    t1.requestFocus();                                 
			}
		  
		if(target==bclear)                                           
		{ 
			String temp = "";
			backInt = 2;
			t1.setText(temp);
		    t1.requestFocus();                                   
		}
   }                                                           
   
   void init()                                                                   
   {                                                                            
      //try                                                                     
      //{                                                                       
      //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());    
      //}                                                                       
      //catch(Exception e){}                                                    
                                                                                
      JFrame f=new JFrame();                                                    
      Container c=f.getContentPane();                                           
                                                                                
      GridBagLayout gbl=new GridBagLayout();                                    
      GridBagConstraints gbc=new GridBagConstraints();                          
      gbc.fill=GridBagConstraints.HORIZONTAL;                                   
      c.setLayout(gbl);         
      
      t1=new JTextField(15);                                                    
      t1.addActionListener(this);                                               
      t1.setHorizontalAlignment(JTextField.RIGHT);   
      t1.addKeyListener(new Kalk());
      //t1.setEditable(false);
      gbc.gridx=0;                                                              
      gbc.gridy=0;                                                              
      gbc.gridwidth=7;   
      gbc.gridheight=1;
      gbc.ipadx=0;                                                              
      gbc.ipady=5;                                                              
      gbc.insets=new Insets(5,5,0,5);                                           
      gbl.setConstraints(t1,gbc);                                               
      c.add(t1);  
      
                                                                                
      int[] buttonXY = {0, 1,     1, 1,    2, 1,    0, 2,    1, 2,     2, 2,    0, 3,    1, 3,    2, 3,   0, 4};
      String[] buttonNames = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
      int[] buttonWeight = {1, 1, 1, 1, 1, 1, 1, 1, 1, 2};
      int[] buttonInsert = {5,5,0,0,
    		  			5,0,0,0,
    		  			5,0,0,5,
    		  			0,5,0,0,
    		  			0,0,0,0,
    		  			0,0,0,5,
    		  			0,5,0,0,
    		  			0,0,0,0,
    		  			0,0,0,5,
    		  			0,5,5,0,};
      
      
      int[] buttonXYSign = {4, 1,   4, 2,  4, 3,  4, 4, 0, 5};
      String[] buttonNamesSign = {"+", "-", "*", "/", "="};
      String[] buttonNamesSign2 = {"^", "#", "%", "back"};
      int[] buttonInsertSign = {5,5,0,5,
	  							0,5,0,5,
	  							0,5,0,5,
	  							0,5,5,5,
	  							5,5,5,0};
                                                                                                                                             
                                                                                                                                                               
      for (int i=0; i < 10; i++){                                                                          
	      button[i]=new JButton(buttonNames[i]);                                                      
	      button[i].addActionListener(this);                                               
	      button[i].setFocusable(false);                                                   
	      gbc.gridx=buttonXY[ 2*i+0 ];                                                              
	      gbc.gridy=buttonXY[ 2*i+1 ];                                                              
	      gbc.gridwidth=buttonWeight[i];     
	      gbc.gridheight=1;
	      gbc.ipadx=0;                                                              
	      gbc.ipady=0;                                                              
	      gbc.insets=new Insets(buttonInsert[ 4*i+0 ],buttonInsert[ 4*i+1 ], buttonInsert[ 4*i+2 ], buttonInsert[ 4*i+3 ]);                                           
	      gbl.setConstraints(button[i],gbc);                                               
	      c.add(button[i]);  
      }
                                                     
      
      brow=new JButton("=");                                                    
      brow.addActionListener(this);                                             
      brow.setFocusable(false);                                                 
      brow.setToolTipText("wykonaj działanie");                                 
      gbc.gridx=0;                                                              
      gbc.gridy=5;                                                              
      gbc.gridwidth=2;                                                          
      gbc.ipadx=30;                                                             
      gbc.ipady=0;                                                              
      gbc.insets=new Insets(5,5,5,0);                                           
      gbl.setConstraints(brow,gbc);                                             
      c.add(brow);                                                              
      
      
      bdot=new JButton(".");                                                    
      bdot.addActionListener(this);                                             
      bdot.setFocusable(false);                                                                                 
      gbc.gridx=2;                                                              
      gbc.gridy=4;                                                              
      gbc.gridwidth=1;                                                          
      gbc.ipadx=0;                                                             
      gbc.ipady=0;                                                              
      gbc.insets=new Insets(0,0,5,5);                                           
      gbl.setConstraints(bdot,gbc);                                             
      c.add(bdot);
      
      
      bclear=new JButton("Cl");                                                    
      bclear.addActionListener(this);                                             
      bclear.setFocusable(false);                                                                                  
      gbc.gridx=3;                                                              
      gbc.gridy=5;                                                              
      gbc.gridwidth=3;                                                          
      gbc.ipadx=0;                                                             
      gbc.ipady=0;                                                              
      gbc.insets=new Insets(5,0,5,5);                                           
      gbl.setConstraints(bclear,gbc);                                             
      c.add(bclear);      
      
      for (int i=0; i < 4; i++){ 
	      buttonSign[i]=new JButton(buttonNamesSign[i]);                                                    
	      buttonSign[i].addActionListener(this);                                             
	      buttonSign[i].setFocusable(false);                                                                                 
	      gbc.gridx=buttonXYSign[ 2*i+0 ];                                                              
	      gbc.gridy=buttonXYSign[ 2*i+1 ];                                                              
	      gbc.gridwidth=1;                                                          
	      gbc.ipadx=30;                                                             
	      gbc.ipady=0;                                                              
	      gbc.insets=new Insets(buttonInsertSign[ 4*i+0 ],buttonInsertSign[ 4*i+1 ],
						buttonInsertSign[ 4*i+2 ], buttonInsertSign[ 4*i+3 ]);                                           
	      gbl.setConstraints(buttonSign[i],gbc);                                             
	      c.add(buttonSign[i]);
      }
      
      for (int i=0; i < 4; i++){ 
	      buttonSign2[i]=new JButton(buttonNamesSign2[i]);                                                    
	      buttonSign2[i].addActionListener(this);                                             
	      buttonSign2[i].setFocusable(false);                                                                           
	      gbc.gridx=buttonXYSign[ 2*i+0 ] + 1;                                                              
	      gbc.gridy=buttonXYSign[ 2*i+1 ];                                                              
	      gbc.gridwidth=1;                                                          
	      gbc.ipadx=30;                                                             
	      gbc.ipady=0;                                                              
	      gbc.insets=new Insets(buttonInsertSign[ 4*i+0 ],buttonInsertSign[ 4*i+1 ],
						buttonInsertSign[ 4*i+2 ], buttonInsertSign[ 4*i+3 ]);                                           
	      gbl.setConstraints(buttonSign2[i],gbc);                                             
	      c.add(buttonSign2[i]);
      }
                         
                                                       
      f.pack();                                                                 
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);                         
      f.setTitle("Kalk");                                                       
      f.setVisible(true);                                                       
   }                                                                            
   
   public static void main(String[] args)          
   {                                               
      //do wersji 1.4                              
      //new Kalk().init();                         
                                                   
      //od wersji 1.5                              
         SwingUtilities.invokeLater(new Runnable() 
      {                                            
         public void run()                         
         {                                         
            new Kalk().init();                     
         }                                         
      });                                          
   }                                               
}