package zadanie1;

class SilnikKulki extends Thread
{
   Kulka a;
   Belka b;
   
   SilnikKulki(Kulka a, Belka b) 
   {                    
      this.a=a;
      this.b=b;
      start();          
   }                    
   
   public void run()                   
   {                                  
      try                             
      {                               
         while(true)                  
         {                            
            a.nextKrok();             
            sleep(15);
            a.contact(b);;
         }                            
      }                               
      catch(InterruptedException e){} 
   }                                  
}