package zadanie3;

import java.util.ArrayList;

class SilnikKulki extends Thread
{
   Kulka a;
   Belka down;
   ArrayList <Belka> BelkiList = new ArrayList();
   
   private int level = 1;
   private int setDaley(){
	   int ret;
	   switch (level) {
	   case (1): ret = 15;
	   	   break;
	   case (2): ret = 10;
	   	   break;
	   default: ret = 20;
	   }
	   return ret;
   }
   
   SilnikKulki(Kulka a, ArrayList <Belka> list, Belka down) 
   {                    
      this.a=a;
      this.down=down;
      this.BelkiList=list;
      start();          
   }                    
   
   public void run()                   
   {                                  
      try                             
      {                               
         while(true)                  
         {                            
            a.nextKrok();             
            sleep(this.setDaley());
            a.contact(down);
            for (int i = 0; i < Plansza.countBelki; i++){
            	a.contactDelete(BelkiList.get(i));
            }
            a.sizeObstacles();
         }                            
      }                               
      catch(InterruptedException e){} 
   }                                  
}