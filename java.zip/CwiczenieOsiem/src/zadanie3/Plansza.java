package zadanie3;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.ArrayList;

class Plansza extends JPanel implements MouseMotionListener
{
   ArrayList <Belka> BelkiList = new ArrayList();
   Belka down;
   Belka b;
   Kulka a;
   SilnikKulki s;
   
   public static final int countBelki=10;
   public int countRows;
   public static final int heightBelka=10;
   public int leaveBelki=countBelki;
   
   Plansza()                         
   {                                 
      super();                       
      addMouseMotionListener(this);  
          
      down=new Belka();
      for (int i = 0; i < countBelki; i++){
    	  b=new Belka();
    	  BelkiList.add(b);
      }
      
      a=new Kulka(this,100,100,1,1); 
      s=new SilnikKulki(a, BelkiList, down);          
   }   
   
   
   public int getLeaveBelki(){
	   return leaveBelki;
   }
   
   public void setLeaveBelki(int decrease){
	   this.leaveBelki -= decrease;
   }
   
   public void paintComponent(Graphics g) 
   {                                      
      super.paintComponent(g);            
      Graphics2D g2d=(Graphics2D)g;       
       
      g2d.fill(a);                        
      g2d.fill(down);

      for (int i = 0; i < countBelki; i++){
    	  g2d.fill(BelkiList.get(i));
	  }
   }   
   
   
   public void sizeObstacles(){
	   countRows = this.getRows();
	   int tempColomn = countRows;
	   int tempWidth = this.getWidth() / countRows;
	   int tempHeight = heightBelka;
	   int element = 0;
	   int zerosColumn = 0;
	   
	   down.set(getWidth()/4, getHeight()-10, getWidth()/2, 10); 
	   
	   for (int i = 0; i < countRows; i++){
		   for (int j = 0; j < tempColomn; j++){
			   if (element < countBelki && BelkiList.get(element).getVisible()){
				   BelkiList.get(element).set(j*tempWidth + zerosColumn, i*tempHeight, tempWidth, tempHeight);
			   }
			   element += 1;
		   }
		   tempColomn--;
		   zerosColumn+=tempWidth/2;
	   }
   }
   
   
   private int getRows(){
	   int row = 1;
	   int tempBelki = countBelki;
	   for (;;){
		   if (row >= tempBelki)	return row;
		   else{
			   tempBelki-=row;
			   row+=1;
		   }
	   }
   }
   
   public void mouseMoved(MouseEvent e) 
   {                                    

   }                                    
   
   public void mouseDragged(MouseEvent e) 
   {   
	   Point p = (Point)(e.getPoint());
	   if (down.closeCenter(e, p)) down.setX(e.getX()-(int)down.getWidth()/2, this);
	   
	   repaint();                           
   }                                      
}
