package zadanie3;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;

class Kulka extends Ellipse2D.Float
{
   Plansza p;
   int dx,dy;
   int lastPX, lastPY;
   boolean statusWindow = false;
   
   Kulka(Plansza p,int x,int y,int dx,int dy) 
   {                                          
      this.x=x;                               
      this.y=y;                               
      this.width=10;                          
      this.height=10;                         
                                              
      this.p=p;                               
      this.dx=dx;                             
      this.dy=dy;  
      
      this.lastPX=p.getWidth();
      this.lastPY=p.getHeight();
   }                                          
   
   void nextKrok()                                        
   {                                                     
      x+=dx;                                             
      y+=dy;                                             

      if(getMaxY()>p.getHeight()){
    	  if (statusWindow == true){
	    	  JFrame alert=new JFrame(); 
	    	  JOptionPane.showMessageDialog(alert,
	    			    "Przegrales. Kulka wyszla z pola.");                                        
	                                                             
	    	  System.exit(0); 
    	  }
    	  else if (p.getWidth() != 0 && p.getHeight() != 0)	statusWindow = true;
      }
      
      else if(p.getLeaveBelki() <= 0){
		  JFrame alert=new JFrame(); 
    	  JOptionPane.showMessageDialog(alert,
    			    "Wygrales. Niema belek");                                        
                                                             
    	  System.exit(0); 
	  }
      
      if(getMinX()<0 || getMaxX()>p.getWidth())  dx=-dx; 
      if(getMinY()<0) dy=-dy;
   }      
   
   boolean contact(Belka b){
	   boolean change=false;
	   
	   if(b.getMinX()<getMaxX() && b.getMinX()>getMinX()){
		   if(b.getMinY()<getCenterY() && b.getMaxY()>getCenterY()){
			   dx=-Math.abs(dx);
			   change=true;
		   }
		}
	   		
	   
	   if(b.getMaxX()>getMinX() && b.getMaxX()<getMaxX()){
		   if(b.getMinY()<getCenterY() && b.getMaxY()>getCenterY()){
			   dx=Math.abs(dx);
			   change=true;
		   }
	   }
	   
	   if(b.getMinY()<getMaxY() && b.getMinY()>getMinY()){
		   if(b.getMinX()<getCenterX() && b.getMaxX()>getCenterX()){
			   dy=-Math.abs(dx);
			   change=true;
		   }
	   }
	   
	   if(b.getMaxY()>getMinY() && b.getMaxY()<getMaxY()){
		   if(b.getMinX()<getCenterX() && b.getMaxX()>getCenterX()){
			   dy=Math.abs(dx);
			   change=true;
		   }
	   }
	   
	   p.repaint();
	   return change;
   }
   
   
   void contactDelete(Belka b){
	   if (this.contact(b)){
		   b.unvisible();
		   p.setLeaveBelki(1);
	   }
   }
   
   void sizeObstacles(){
	   if ((lastPX != p.getWidth()) || (lastPY != p.getHeight())){
		   p.sizeObstacles();
		   lastPX=p.getWidth();
		   lastPY=p.getHeight();
	   }
	   
   }
   
}
