package zadanie2;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;

class Plansza extends JPanel implements MouseMotionListener
{
   Belka top;
   Belka down;
   Belka right;
   Belka left;
   Kulka a;
   SilnikKulki s;
   
   Plansza()                         
   {                                 
      super();                       
      addMouseMotionListener(this);  
      
      top=new Belka();      
      down=new Belka(); 
      right=new Belka(); 
      left=new Belka();
      
      a=new Kulka(this,100,100,1,1); 
      s=new SilnikKulki(a, top, down, right, left);          
   }                                 
   
   public void paintComponent(Graphics g) 
   {                                      
      super.paintComponent(g);            
      Graphics2D g2d=(Graphics2D)g;       
       
      g2d.fill(a);                        
      g2d.fill(top);
      g2d.fill(down);
      g2d.fill(right);
      g2d.fill(left);
   }   
   
   void sizeObstacles(){
	   top.set(getWidth()/4, 0, getWidth()/2, 10);      
	   down.set(getWidth()/4, getHeight()-10, getWidth()/2, 10); 
	   right.set(getWidth()-10, getHeight()/4, 10, getHeight()/2);
	   left.set(0, getHeight()/4, 10, getHeight()/2); 
   }
   
   public void mouseMoved(MouseEvent e) 
   {                                    

   }                                    
   
   public void mouseDragged(MouseEvent e) 
   {   
	   Point p = (Point)(e.getPoint());
	   if (top.closeCenter(e, p)) top.setX(e.getX()-(int)top.getWidth()/2, this);
	   if (down.closeCenter(e, p)) down.setX(e.getX()-(int)down.getWidth()/2, this);
	   if (right.closeCenter(e, p)) right.setY(e.getY()-(int)right.getHeight()/2, this);
	   if (left.closeCenter(e, p)) left.setY(e.getY()-(int)left.getHeight()/2, this);
	   
	   repaint();                           
   }                                      
}