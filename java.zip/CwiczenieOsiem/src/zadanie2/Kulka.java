package zadanie2;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;

class Kulka extends Ellipse2D.Float
{
   Plansza p;
   int dx,dy;
   int lastPX, lastPY;
   boolean status = false;
   
   Kulka(Plansza p,int x,int y,int dx,int dy) 
   {                                          
      this.x=x;                               
      this.y=y;                               
      this.width=10;                          
      this.height=10;                         
                                              
      this.p=p;                               
      this.dx=dx;                             
      this.dy=dy;  
      
      this.lastPX=p.getWidth();
      this.lastPY=p.getHeight();
   }                                          
   
   void nextKrok()                                        
   {                                                     
      x+=dx;                                             
      y+=dy;                                             

      if((getMinX()<0 || getMaxX()>p.getWidth()) || (getMinY()<0 || getMaxY()>p.getHeight())){
    	  if (status == true){
	    	  JFrame alert=new JFrame(); 
	    	  JOptionPane.showMessageDialog(alert,
	    			    "Przegrales. Kulka wyszla z pola.");                                        
	                                                             
	    	  System.exit(0); 
    	  }
    	  else{
    		  if (p.getWidth() != 0 && p.getHeight() != 0)	status = true;
    	  }
      }                                                                                             
   }      
   
   void contact(Belka b){
	   if(b.getMinX()<getMaxX() && b.getMinX()>getMinX())
		  if(b.getMinY()<getCenterY() && b.getMaxY()>getCenterY())  dx=-Math.abs(dx); 
	   
	   if(b.getMaxX()>getMinX() && b.getMaxX()<getMaxX())
		   if(b.getMinY()<getCenterY() && b.getMaxY()>getCenterY())  dx=Math.abs(dx); 
	   
	   if(b.getMinY()<getMaxY() && b.getMinY()>getMinY())
		   if(b.getMinX()<getCenterX() && b.getMaxX()>getCenterX())  dy=-Math.abs(dx); 
	   
	   if(b.getMaxY()>getMinY() && b.getMaxY()<getMaxY())
		   if(b.getMinX()<getCenterX() && b.getMaxX()>getCenterX())  dy=Math.abs(dx);
	    
	   p.repaint();
   }
   
   void sizeObstacles(){
	   if ((lastPX != p.getWidth()) || (lastPY != p.getHeight())){
		   p.sizeObstacles();
		   lastPX=p.getWidth();
		   lastPY=p.getHeight();
	   }
	   
   }
   
}
