package zadanie2;

import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.awt.geom.*;

class Belka extends Rectangle2D.Float
{
	Belka()       
	   {                  
	      this.x=0;       
	      this.y=0;     
	      this.width=0;  
	      this.height=0; 
	   }    
	
   Belka(int x, int y, int width, int height)       
   {                  
      this.x=x;       
      this.y=y;     
      this.width=width;  
      this.height=height; 
   }                  
   
   void setX(int x, Plansza p) 
   {  
	  int buforX = x;
	  if (buforX < 0)   buforX = 0;
	  else if (buforX+width > p.getWidth()){
		  buforX = (int)(p.getWidth()-(float)width);
	  }
      this.x=buforX;     
   }    
   
   void setY(int y, Plansza p) 
   {    
	  int buforY = y;
	  if (buforY < 0)   buforY = 0;
	  else if (buforY+height > p.getHeight()){
		  buforY = (int)(p.getHeight()-(float)height);
		  }
      this.y=buforY;     
   } 
   
   void set(int x, int y, int width, int height){
	   this.x=x;       
	   this.y=y;     
	   this.width=width;  
	   this.height=height;
   }
   
   boolean closeCenter(MouseEvent e, Point p){
	   double X = (e.getX() - this.getCenterX());
	   double Y = (e.getY() - this.getCenterY());
	   double distance = Math.sqrt(X*X +Y*Y);
	   if ((distance < 100) || this.contains(p)) return true;
	   else return false;
   }
   
}