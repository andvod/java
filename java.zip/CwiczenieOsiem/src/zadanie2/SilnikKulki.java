package zadanie2;

class SilnikKulki extends Thread
{
   Kulka a;
   Belka top;
   Belka down;
   Belka right;
   Belka left;
   
   private int level = 1;
   private int setDaley(){
	   int ret;
	   switch (level) {
	   case (1): ret = 15;
	   	   break;
	   case (2): ret = 10;
	   	   break;
	   default: ret = 20;
	   }
	   return ret;
   }
   
   SilnikKulki(Kulka a, Belka top, Belka down, Belka right, Belka left) 
   {                    
      this.a=a;
      this.top=top;
      this.down=down;
      this.right=right;
      this.left=left;
      start();          
   }                    
   
   public void run()                   
   {                                  
      try                             
      {                               
         while(true)                  
         {                            
            a.nextKrok();             
            sleep(this.setDaley());
            a.contact(top);
            a.contact(down);
            a.contact(right);
            a.contact(left);
            a.sizeObstacles();
         }                            
      }                               
      catch(InterruptedException e){} 
   }                                  
}