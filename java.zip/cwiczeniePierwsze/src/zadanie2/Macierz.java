package zadanie2;

public class Macierz
	{
	int a11,a12,a21,a22;
		   
	Macierz(int a11,int a12,int a21,int a22) 
	{                                        
		this.a11=a11;                         
		this.a12=a12;                         
		this.a21=a21;                         
		this.a22=a22;                         
	}                                        
		   
	int wyznacznik()             
	{                            
		return a11*a22 - a12*a21; 
	}                            
		   
	Macierz dodaj(Macierz obj)      
	{                               
		int i=this.a11 + obj.a11;    
		int j=this.a12 + obj.a12;    
		int k=this.a21 + obj.a21;    
		int l=this.a22 + obj.a22;    
		                                   
		return new Macierz(i,j,k,l); 
	}   
	
	Macierz pomnoz(Macierz obj)      
	{                               
		int i=this.a11 * obj.a11 + this.a12 * obj.a21;    
		int j=this.a11 * obj.a12 + this.a12 * obj.a22;    
		int k=this.a21 * obj.a11 + this.a22 * obj.a21;    
		int l=this.a21 * obj.a12 + this.a22 * obj.a22;    
		                                   
		return new Macierz(i,j,k,l); 
	}                          
	
	public static void main(String[] args){
		Macierz A = new Macierz(2, 4, 5, 6);
		Macierz B = new Macierz(5, 8, 1, 2);
		int wyzn = A.wyznacznik();
		System.out.println(wyzn);
		System.out.println(B.wyznacznik());
		Macierz C = A.dodaj(B);
		System.out.println(" " + C.a11 + " "+C.a12+ " " + C.a21 + " " +C.a22);
		
		A = new Macierz(54, 24, 15, 54);
		B = new Macierz(23, 76, 45, 76);
		wyzn = A.wyznacznik();
		System.out.println(wyzn);
		System.out.println(B.wyznacznik());
		C = A.dodaj(B);
		System.out.println(" " + C.a11 + " "+C.a12+ " " + C.a21 + " " +C.a22);
		C = A.pomnoz(B);
		System.out.println(" " + C.a11 + " "+C.a12+ " " + C.a21 + " " +C.a22);
	}
}