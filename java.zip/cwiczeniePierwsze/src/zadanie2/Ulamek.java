package zadanie2;


public class Ulamek
{
   int licznik, mianownik;
   
   Ulamek(int licznik, int mianownik) 
   {                                  
	   this.licznik = licznik;
	   this.mianownik = mianownik;
   }                                  
   
   double rozwiniecieDziesietne() 
   {                              
       return (double)licznik / mianownik;                           
   }                              
   
   Ulamek dodaj(Ulamek obj) 
   {   
	   int l = this.licznik * obj.mianownik + this.mianownik * obj.licznik;
	   int m = this.mianownik * obj.mianownik;
	   Ulamek ulamek = new Ulamek(l, m);
	   ulamek.skroc();
	   return ulamek;
   }                        
   
   void skroc() 
   {   
	   int divider = this.licznik;
	   while ((this.licznik > 1) && (divider > 1)){
		   if ((this.licznik%divider == 0) && (this.mianownik%divider == 0)){
			   this.licznik /= divider;
			   this.mianownik /= divider;
			   System.out.println("divider = " + divider);
		   }
		   else
			   divider--;
	   }
   } 
   
   public static void main(String args[]){
	   Ulamek obj1 = new Ulamek(20, 35);
	   System.out.println(obj1.rozwiniecieDziesietne());
	   
	   Ulamek obj2 = new Ulamek(12, 20);
	   obj2.skroc();
	   System.out.println(obj2.licznik + " " + obj2.mianownik);
	   Ulamek obj3 = obj1.dodaj(obj2);
	   System.out.println(obj3.licznik + " " + obj3.mianownik);
   }
}