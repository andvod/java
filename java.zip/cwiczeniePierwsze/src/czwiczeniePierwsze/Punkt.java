package czwiczeniePierwsze;

/**
 * 
 * @author Andrii
 * @version 1.0
 * @since 1.0
 * 
 *
 */

public class Punkt {
	
	/**
	 * Podanie wspolrzednych
	 */
	
	double x, y;
	
	Punkt(){
		this.x = 0;
		this.y = 0;
	}
	
	Punkt(double x, double y){
		this.x = x;
		this.y = y;
	}
	

}
