package czwiczeniePierwsze;

/**
 * 
 * @author Andrii
 * @version 1.0
 * @since 1.0
 *
 */

public class Okrag {
	
	/**
	 * Klasa obslugujaca okreg
	 */
	
	double promien;
	Punkt srodek = new Punkt();
	
	Okrag()            
	{                      
	   this.promien=0;
	}                      
	
	Okrag(double promien)  
	{                                          
	   this.promien = promien;               
	}                                          
	
	double pole()                
	{                            
	   return Math.PI*Math.pow(promien, 2); 
	}   
	   
	double obwod(){
		   return 2*Math.PI*promien;
	}                          
	
	void przesun(double u,double v){
		   srodek.x += u;
		   srodek.y += v;
	}
	
	void przesun(Punkt obj){
		srodek.x += obj.x;
		srodek.y += obj.y;
	}
	
	void info(){
		   System.out.println(srodek.x);
		   System.out.println(srodek.y);
	}
	
	private double odleglosc(Punkt obj){
		return Math.sqrt(Math.pow((obj.x-srodek.x), 2) + Math.pow((obj.y-srodek.y), 2));
	}
	
	boolean zawiera(Punkt obj){
		double wektor = odleglosc(obj);
		if (wektor<promien){
			return true;
		}
		else{
			return false;
		}
	}
	
	boolean przecina(Okrag obj){
		double wektor = odleglosc(obj.srodek);
		if ((wektor-promien)<obj.promien){
			return true;
		}
		else{
			return false;
		}
	}
}
