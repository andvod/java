package czwiczeniePierwsze; // package czwiczeniePierwsze

public class Program
{
   public static void main(String[] args)         
   {                                             
      Prostokat obj;                             
      obj=new Prostokat(3,4);                    
      double x=obj.pole(); 
      double obwod = obj.obwod();
                                                 
      System.out.println("Pole prostokata: "+x); 
      System.out.println("Obwod prostokata: "+obwod);
      obj.info();
      obj.przesun(2, 3);
      obj.info();
      
      Okrag kolo = new Okrag(5);
      Punkt one = new Punkt(-2, -1);
      Punkt two = new Punkt(1.5, 2);
      kolo.przesun(two);
      System.out.println(obj.zawiera(one));
      System.out.println(obj.zawiera(two));
      System.out.println(obj.przecina(kolo));
      kolo.przesun(8, 8);
      System.out.println(obj.przecina(kolo));
   }                                             
}
