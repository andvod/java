package czwiczeniePierwsze;

/**
 * 
 * @author Andrii
 * @version 1.0
 * @since 1.0
 *
 */

public class Prostokat
{
   double dlugosc;
   double szerokosc;
   Punkt srodek = new Punkt();
   
   Prostokat()            
   {                      
      this.dlugosc=0.0;   
      this.szerokosc=0.0; 
   }                      
   
   Prostokat(double dlugosc,double szerokosc)  
   {                                          
      this.dlugosc=dlugosc;                   
      this.szerokosc=szerokosc;               
   }                                          
   
   double pole()                
   {                            
      return dlugosc*szerokosc; 
   }   
      
   double obwod(){
	   return 2*(this.dlugosc+this.szerokosc);
   }                          
   
   void przesun(double u,double v){
	   srodek.x += u;
	   srodek.y += v;
   }
   
	void przesun(Punkt obj){
		srodek.x += obj.x;
		srodek.y += obj.y;
	}
   
   void info(){
	   System.out.println(srodek.x);
	   System.out.println(srodek.y);
   }

	private double odleglosc(Punkt obj){
		return Math.sqrt(Math.pow((obj.x-srodek.x), 2) + Math.pow((obj.y-srodek.y), 2));
	}
   
   boolean zawiera(Punkt obj){
	   if ((Math.abs(obj.x-srodek.x)<szerokosc/2)&&(Math.abs(obj.y-srodek.y)<dlugosc/2)){
		   return true;
	   }
	   else{
		   return false;
	   }
   }
   
   boolean przecina(Okrag obj){
	   double wektor = odleglosc(obj.srodek);
	   if (((wektor-obj.promien)<szerokosc) && ((wektor-obj.promien)<dlugosc)){
		   return true;
	   }
	   else{
		   return false;
	   }
   }
   
}