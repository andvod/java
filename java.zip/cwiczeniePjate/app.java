import java.awt.*;
import javax.swing.*;

public class app extends JApplet{
	public void paint(Graphics g){
		super.paint(g);
		g.drawString("wow is Ok", 10, 10);
	}
}