package SerwerHTTP;

import java.io.*;
import java.net.*;
import java.awt.*;
 
public class SerwerHTTP
{
	private static ServerSocket serv = null;
	private static int port;
	
   public static void main(String[] args) throws IOException                
   {                          
	   if (args.length == 0){
		   port = 8000;
	   }else if (args.length == 1){
		   port = Integer.parseInt(args[0]);
	   }else{
		   System.out.println("Too many members");
		   System.exit(1);
	   }
	   
	   try
	   {
		   serv=new ServerSocket(port);
	   }
	   catch(BindException ex){
		   System.out.println(ex);;
		   System.exit(1);
	   }
      
 
      while(true)                                                          
      {                                                                                                         
         System.out.println("Oczekiwanie na polaczenie...");               
         Socket sock=serv.accept();   
         
         //String url = "http.html";
         //File htmlFile = new File(url);
         //Desktop.getDesktop().browse(htmlFile.toURI());
         
         File f = new File("kawa.jpg");
         
         new ObslugaZadania(sock, "image/jpeg", f).start();
         new ObslugaZadania(sock, "html", null).start();
         //new ObslugaZadania(sock, "image/jpeg", f).start();
         
      } 
      //serv.close();
   }                                                                       
}