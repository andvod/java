package SerwerHTTP;

import java.io.*;
import java.net.*;

public class ObslugaZadania extends Thread
{
	   Socket sock;
	   InputStream is;
	   OutputStream os;
	   BufferedReader inp;
	   DataOutputStream outp;
	   
	   String type;
	   File file;
	   String accept;
	   
	   ObslugaZadania(Socket klientSocket, String type, File file) throws IOException  
	   {     
	      this.sock=klientSocket;   
	      this.is=sock.getInputStream();                             
	      this.os=sock.getOutputStream();                           
	      this.inp=new BufferedReader(new InputStreamReader(is)); 
	      this.outp=new DataOutputStream(os); 
	      this.type = type;
	      this.file = file;
	   }                                   
	 
	   public void run()
	   {     
		   try
		   {
	         //przyjecie zadania (request)                                     
	         String request=inp.readLine(); 
	         while( inp.ready() ){
	        	 request += "\n" + new String(inp.readLine());
	         }
	         System.out.println(request);
	         
	         int beginIndex = request.lastIndexOf("Accept:");
	         String accept = request.substring(beginIndex).split("\n")[0];
	         System.out.println(accept + "\n");
	 
	         //wyslanie odpowiedzi (response)                                  
	         if(request.startsWith("GET"))                                     
	         {     
	        	 if (this.type.equals("html"))	htmlSend();
	        	 else	imageSend();
	         }                                                                 
	         else                                                              
	         {                                                                 
	            outp.writeBytes("HTTP/1.1 501 Not supported.\r\n");            
	         }
                                         
	         inp.close();                                                      
	         outp.close();                                                     
	         sock.close();
		   }
		   catch(IOException ex){
			   
		   }
	   }
	   
	   
	   private void htmlSend() throws IOException 
	   {
		   outp.writeBytes("HTTP/1.1 200 OK\r\n");                        
           outp.writeBytes("Content-Type: text/html \r\n");                               
           outp.writeBytes("\r\n");  
           
		   outp.writeBytes("<html>\r\n");                                 
	       outp.writeBytes("<H1>Strona testowa</H1>\r\n");       
	       outp.writeBytes("</html>\r\n");
	   }
		   
	   private void imageSend() throws IOException 
	   {
		   if (file.exists())
		   {
	           int size = (int)file.length();
	      	 
	           outp.writeBytes("HTTP/1.1 200 OK\r\n");                        
	           outp.writeBytes("Content-Type:\r\n");               
	           outp.writeBytes("Content-Length:" + size + "\r\n");                       
	           outp.writeBytes("\r\n");   
	          
	           FileInputStream fis = new FileInputStream(file);
	           System.out.println(fis.available());
	          
	           byte[] bufor;
	           bufor=new byte[1024];
	           int n=0;
	           
	           while ((n = fis.read(bufor)) != -1 )
	           {
	        	   outp.write(bufor, 0, n);
	           }
	          
	           fis.close();
		   }
		   else
		   {
			   outp.writeBytes("HTTP/1.1 200 OK\r\n");                        
	           outp.writeBytes("Content-Type: text/html \r\n");                                    
	           outp.writeBytes("\r\n");  
	           
	           outp.writeBytes("<h1>HTTP/1.0 404 Not Found</h1>");
		   }
	   }
	}
