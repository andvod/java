package zadanie1;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class Program extends Exception
{
   public static void main(String[] args)                
   {                                                     
	   Rectangle2D.Float obj1;                                        
      obj1=new Rectangle2D.Float(100,100,140,100);       
      
      Ellipse2D.Float obj2;                                        
      obj2=new Ellipse2D.Float(100,150,140,100); 
      
      Point2D.Float obj3;                                        
      obj3=new Point2D.Float(200, 200); 
      
      Rectangle2D.Float obj4;                                        
      obj4=new Rectangle2D.Float(100,220,140,100); 
 
      Plansza p = new Plansza();  
      	                                        
      p.addFigure(obj1); 
      p.addFigure(obj2); 
      p.addPoint(obj3);
      p.addFigure(obj4); 
      
      JFrame jf=new JFrame();                            
      jf.add(p);  
 
      jf.setTitle("Test grafiki");                       
      jf.setSize(400,400);                               
      jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
      jf.setVisible(true);                               
   }                                                     
}