package zadanie1;

import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;
import java.util.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;
import java.awt.font.GlyphVector;
import java.awt.font.FontRenderContext;


class Plansza extends JPanel
{
	ArrayList <Shape> figury = new <Shape> ArrayList();
   Ellipse2D.Float e;
   Rectangle2D.Float r1 = null;
   Rectangle2D.Float r2 = null;
   Point2D.Float p;

   Plansza(){          
   } 
   
   
   public void addFigure(Ellipse2D.Float figura){
	   e = figura;
	   figury.add(figura);
   }
   
   
   public void addFigure(Rectangle2D.Float figura){
	   if ( r1 == null )	r1 = figura;
	   else r2 = figura;
	   
	   figury.add(figura);
   }
   
   
   public void addPoint(Point2D.Float p){
	   this.p = p;
   }
   
   public void drawRectImg(Graphics2D g2d){
	   String plik="water.jpg";
	      BufferedImage img;
	      try
	      {
	      	File f=new File(plik);
	      	img=ImageIO.read(f);
	      	img = img.getSubimage(0, 0, (int)r2.getWidth(), (int)r2.getHeight());
	      	g2d.drawImage(img, new AffineTransform(1f,0f,0f,01f,r2.getX(),r2.getY()), null);
	      }
	      catch(IOException e)
	      {
	      	System.err.println("Problem z plikiem");
	      }
   }
   
   public void setPolygon(Graphics2D g2d){
	   Stroke dashed = new BasicStroke(5, BasicStroke.CAP_ROUND, BasicStroke.CAP_ROUND, 10f);
	   g2d.setStroke(dashed);
	   g2d.setColor(Color.BLUE);
	   
	   ArrayList <Integer> polygon = new ArrayList<>(Arrays.asList(100, 100, 150, 20, 200, 80, 100, 100));
	   
	   Polygon p = new Polygon();
	   for (int i = 0; i < 4; i++){
		   System.out.print(i);
		   p.addPoint(polygon.get(2*i),  polygon.get(2*i+1));
	   }
	   g2d.drawPolygon(p);
	   
	   dashed = new BasicStroke(8, BasicStroke.CAP_ROUND, BasicStroke.CAP_ROUND, 10f);
	   g2d.setStroke(dashed);
	   
	   ArrayList <Integer> polygon1 = new ArrayList<>(Arrays.asList(100, 130, 170, 20, 235, 100));
	   
	   Polygon p1 = new Polygon();
	   for (int i = 0; i < 3; i++){
		   p1.addPoint(polygon1.get(2*i),  polygon1.get(2*i+1));
	   }
	   g2d.drawPolygon(p1);
   }
   
   
   public void paintComponent(Graphics g) 
   {                                      
      super.paintComponent(g);            
      Graphics2D g2d=(Graphics2D)g;
      AlphaComposite a = AlphaComposite.getInstance(AlphaComposite.SRC_OVER,0.5f);
      g2d.setComposite(a);
      

      float[] dist = {0.0f, 0.8f, 1.0f};
	  Color[] colors = {Color.RED, Color.WHITE, Color.BLUE};
	  RadialGradientPaint radial = new RadialGradientPaint(100, 100, 50, dist, colors);
	  g2d.setPaint(radial);
	  g2d.fill(r1);
	  g2d.setColor(Color.black);
	  
	  Arc2D.Float arc = new Arc2D.Float(Arc2D.OPEN);
      arc.setFrame(100, 200, 140, 100);
      arc.setAngleStart(40);
      arc.setAngleExtent(220);
      a = a.getInstance(AlphaComposite.SRC_OVER,1f);
      g2d.setComposite(a);
      g2d.draw(arc);
      a = a.getInstance(AlphaComposite.SRC_OVER,.5f);
      g2d.setComposite(a);

      g2d.setColor(Color.blue);
      g2d.drawLine(10, 200, 10, 40);
      
      Stroke dashed = new BasicStroke(3);
      g2d.setStroke(dashed);
      g2d.drawLine(20, 200, 20, 40);
      
      dashed = new BasicStroke(8, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER, 10f);
      g2d.setStroke(dashed);
      g2d.drawLine(40, 200, 40, 40);
      
      dashed = new BasicStroke(8, BasicStroke.CAP_ROUND, BasicStroke.JOIN_MITER, 10f, new float[]{ 18.0f, 8.0f, 5.0f, 12.0f }, 0);
      g2d.setStroke(dashed);
      g2d.drawLine(60, 200, 60, 40);
      
	  GradientPaint greentoblack = new GradientPaint(100,0,Color.GREEN,240, 0,Color.BLACK);
	  g2d.setPaint(greentoblack);
	  g2d.fill(e);
	  g2d.setColor(Color.black);

    	//g2d.draw(figura);
	  
	  g2d.setColor(Color.black);
	  this.setPolygon(g2d);
      
	  this.drawRectImg(g2d);
	  
      g2d.setColor(Color.black);
      
      Test t = new Test(this);
	  if ( t.przecinaEllipse(0, 1) )	g2d.drawString("przecina", 100, 50);
	  else								g2d.drawString("nie przecina", 100, 50);
	  
	  if ( t.zawieraEllipse(0, 1) )	g2d.drawString("zawiera", 100, 60);
	  else								g2d.drawString("nie zawiera", 100, 60);
	  
	  if ( t.zawieraPoint(1, p) )	g2d.drawString("zawiera", 100, 70);
	  else								g2d.drawString("nie zawiera", 100, 70);
   }  
   
}