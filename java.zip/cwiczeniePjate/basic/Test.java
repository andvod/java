package zadanie1;

import java.awt.*;
import java.awt.geom.*;

public class Test {
	
	Plansza p;
	
	Test(Plansza p){
		this.p = p;
	}
	
	private class SomeType<T>{
		public T data;
		SomeType(T type){
			data = type;
		}
	}
	
	public boolean przecinaEllipse(int el1, int el2){
		Ellipse2D.Float element2 = (Ellipse2D.Float)p.figury.get(el2);
		double xEl2 = element2.getX();
		double yEl2 = element2.getY();
		double wEl2 = element2.getWidth();
		double hEl2 = element2.getHeight();
		System.out.println(" " + xEl2 + " " + yEl2 + " " + wEl2 + " " + hEl2);
		if ( p.figury.get(el1).intersects(xEl2, yEl2, wEl2, hEl2) ){
			return true;
		}
		else return false;
	}
	
	public boolean zawieraEllipse(int el1, int el2){
		Ellipse2D.Float element2 = (Ellipse2D.Float)p.figury.get(el2);
		double xEl2 = element2.getX();
		double yEl2 = element2.getY();
		double wEl2 = element2.getWidth();
		double hEl2 = element2.getHeight();
		System.out.println(" " + xEl2 + " " + yEl2 + " " + wEl2 + " " + hEl2);
		if ( p.figury.get(el1).contains(xEl2, yEl2, wEl2, hEl2) ){
			return true;
		}
		else return false;
	}
	
	
	public boolean zawieraPoint(int el1, Point2D.Float point){
		return p.figury.get(el1).contains(point);
	}
}
