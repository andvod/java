package zadanie4;

import java.io.*;

public class Osoba implements Serializable
{
   /**
	 * 
	 */
   private static final long serialVersionUID = 5522207441400857499L;
   String imie;
   String nazwisko;
   int rokUrodzenia;
   
   public Osoba(String imie,String nazwisko,int rokUrodzenia) 
   {                                                   
      this.imie=imie;                                  
      this.nazwisko=nazwisko;                          
      this.rokUrodzenia=rokUrodzenia;                  
   }                                                   
   
   public Osoba(BufferedReader br)                                 
   {                                                        
      try                                                   
      {                                                     
         System.out.print("imie: ");                        
         this.imie=br.readLine();                           
                                                            
         System.out.print("nazwisko: ");                    
         this.nazwisko=br.readLine();                       
                                                            
         System.out.print("rok urodzenia: ");               
         this.rokUrodzenia=Integer.parseInt(br.readLine()); 
      }                                                     
      catch(IOException e){}                                
   }                                                        
   
   public String toString()                                     
   {                                                            
      return this.imie+" "+this.nazwisko+" "+this.rokUrodzenia; 
   }                                                            
}
