package zadanie1;
import java.awt.Rectangle;
import java.awt.Point;
import java.awt.Dimension;

class Prostokat extends Rectangle
{
   /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

Prostokat(int a,int b)
   {                      
      super(a,b); 
   }       
   
   Prostokat(Point p, int a,int b) 
   {            
      super(p, new Dimension(a, b));
      
   }    
   
   void info()                  
   {                            
      System.out.println(this); 
   }       
   
   boolean przylega(Prostokat r){
	   return super.intersects(r);
   }
}