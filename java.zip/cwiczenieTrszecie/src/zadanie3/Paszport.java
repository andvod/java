package zadanie3;

public class Paszport extends Dokument {
	String numer;
	String name;
	
	Paszport(String name, String numer){
		this.numer = numer;
		this.name = name;
	}
	
	public boolean czyPasuje(String wzorzec) 
	{    
		if (wzorzec.equalsIgnoreCase(this.name))
			return true; 
		else
			return false;
		
	}                                        
	   
	public String toString() 
	{      
		return ("Paszport pana " + this.name + 
				"\nposiadajacy numer " + this.numer);            
	}                        
}
