package zadanie3;

interface Przeszukiwalne {
	boolean czyPasuje(String wzorzec);
}
