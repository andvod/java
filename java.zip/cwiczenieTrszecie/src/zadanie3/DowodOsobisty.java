package zadanie3;

public class DowodOsobisty extends Dokument {
	
	String firstName;
	String lastName;
	String numer;
	
	DowodOsobisty(String firstName, String lastName, String numer){
		this.firstName = firstName;
		this.lastName = lastName;
		this.numer = numer;
	}
	
	DowodOsobisty(String lastName){
		this.lastName = lastName;
	}
	
	public boolean czyPasuje(String wzorzec) 
	{    
		if (wzorzec.equalsIgnoreCase(this.lastName))
			return true; 
		else
			return false; 
	}
	   
	public String toString() 
	{      
		if ((this.numer == null) && (this.firstName == null))
			return ("Dowod osobisty pana " + this.lastName);
		else
			return ("Dowud osobisty pana " + this.firstName + this.lastName + 
					"\nposiadajacy numer " + this.numer);            
	}               
}
