package zadanie3;

public abstract class Dokument implements Przeszukiwalne {
	String firstName;
	String lastName;
	String name;
	String numer;
	
	public String toString(){
		return "";
	}
}
