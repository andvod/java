package zadanie3;

public class Program
{
   public static void main(String[] args)                                        
   {                                                                             
	   Dokument[] bazaDanych={new Paszport("Serchii Karelin", "EX1298"),
			   new DowodOsobisty("Arek", "Otto", "PO4576"),
			   new Paszport("Aleksey Czarnyszow", "TY2374"),
			   new DowodOsobisty("Gorniak")}; 
       
	   Dokument z;                                                                
	   String wzorzec="Gorniak";                                                  
                                                                                 
	   for(int i=0;i<bazaDanych.length;i++)                                       
	   {                                                                          
		   z=bazaDanych[i];                                                        
		   if(z.czyPasuje(wzorzec))System.out.println("znaleziono: "+z);           
	   }                                                                          
   }                                                                             
}