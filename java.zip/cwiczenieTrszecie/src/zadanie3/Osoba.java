package zadanie3;

public class Osoba {
	protected Paszport paszport;
	protected DowodOsobisty dowodOsobisty;
	
	Osoba(Paszport paszport, DowodOsobisty dowodOsobisty){
		this.paszport = paszport;
		this.dowodOsobisty = dowodOsobisty;
	}
	
	Osoba(DowodOsobisty dowodOsobisty){
		this.dowodOsobisty = dowodOsobisty;
	}
	
	public void setPaszport(Paszport paszport){
		this.paszport = paszport;
	}
}
