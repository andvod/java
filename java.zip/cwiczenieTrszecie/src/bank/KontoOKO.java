package bank;

import java.math.BigInteger;

public class KontoOKO extends Konto{
	
	public String toString(){
		return ("Konto OKO");
	}
}
