package bank;

import java.math.BigInteger;

public abstract class Konto implements Podatek, Oprocentowanie {
	
	protected BigInteger poprszedniStanKonta = new BigInteger("0");
	protected BigInteger aktualnyStanKonta = new BigInteger("0");
	protected BigInteger oplataZaProwadzenieKonta = new BigInteger("7.00");
	protected String valueBruttoNetto;
	
	public BigInteger capitalizacjaOdsetek(){
		//dla jednego miesiaca
		BigInteger stopaProcetowa = new BigInteger("4.0");
		return this.aktualnyStanKonta.multiply(
				new BigInteger("1").add(stopaProcetowa.divide(new BigInteger("12"))));
	}
	
	public int CzyPobierany(){
		return this.aktualnyStanKonta.subtract(this.poprszedniStanKonta).compareTo(Podatek.kwotaDoOpodatkowania);
	}
	
	public boolean BruttoNetto(){
		if (this.valueBruttoNetto.equals("Netto"))
			return true;
		else
			return false;
	}
	
	public BigInteger viewStanKonta(){
		return this.aktualnyStanKonta;
	}
	
	public BigInteger viewPoprzedniegoMiesiacaStanKonta(){
		return this.aktualnyStanKonta;
	}
}
