package bank;

import java.math.BigInteger;

public class KontoDirect extends Konto{
	
	public String toString(){
		return ("Konto Direct");
	}
}
