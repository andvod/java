package bank;

import java.math.BigInteger;

public interface Oprocentowanie {
	
	BigInteger kapitalPoczatkowy = new BigInteger("0");
	BigInteger kapitalKacowy = new BigInteger("0");
	BigInteger capitalizacjaOdsetek();
	
}
