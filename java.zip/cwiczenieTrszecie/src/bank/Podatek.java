package bank;

import java.math.BigInteger;

public interface Podatek {
	
	BigInteger opodatkowane = new BigInteger("0");
	BigInteger kwotaDoOpodatkowania = new BigInteger("1000");
	
	int CzyPobierany();
	boolean BruttoNetto();
}
