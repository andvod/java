package zadanie1;
import java.awt.Rectangle;
import java.awt.*;

public class Program {

	public static void main(String[] args) {
		 Rectangle obj1=new Rectangle(0,0,4,3);                                                      
	     System.out.println(obj1);
	     Rectangle obj2=new Rectangle(1,1,4,3); 
	     Rectangle obj3=new Rectangle(0,0,4,3);
	     obj3 = obj1.intersection(obj2);
	     System.out.println(obj3);
	     
	     obj1=new Rectangle(0,0,4,5); 
	     obj2=new Rectangle(2,0,2,3); 
	     System.out.println(obj1.contains(obj2));
	     
	     Point p = new Point(2, -1);
	     System.out.println(obj1.contains(p));
	     
	     obj1=new Rectangle(1,1,4,5); 
	     obj2=new Rectangle(4,-3,4,3);
	     System.out.println(obj1.intersects(obj2));
	}		

}
