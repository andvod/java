package zadanie2;
import java.io.*;

public class ClassA {
	
	static double KURS_S_Zl=3.60;
	static double KURS_E_Zl=3.80;
	static double KURS_S_E=1.1;
	
	public static void main(String[] args)                                        
	   {                                                                             
	      try                                                                        
	      {                                                                          
	         BufferedReader br=new BufferedReader(new InputStreamReader(System.in)); 
	         System.out.println("Prosze wybrac walute zmiena $, E, Zl");
	         String str1=br.readLine();
	         
	         System.out.println("Prosze wybrac walute na ktora zmienia $, E, Zl");
	         String str2=br.readLine();
	         System.out.println(str2);
	         
	         if (str1.equals("$")){
	        	 if (str2.equals("E")){
			         System.out.print("$: ");                                                
			         String str=br.readLine();
			         double x=Double.parseDouble(str);  
			         String value = String.format("%.2f", x*KURS_S_E);
			         System.out.println("EURO: " + value);
	        	 }
	        	 else if (str2.equals("Zl")){
				     System.out.print("$: ");                                                
				     String str=br.readLine();
				     double x=Double.parseDouble(str);     
				     String value = String.format("%.2f", x*KURS_S_Zl);
				     System.out.println("PLN: " + value);
	        	 }
	         }
	         
	         if (str1.equals("E")){
	        	 if (str2.equals("$")){
			         System.out.print("E: ");                                                
			         String str=br.readLine();
			         double x=Double.parseDouble(str);  
			         String value = String.format("%.2f", x/KURS_S_E);
			         System.out.println("Dollars:" + value);
	        	 }
	        	 else if (str2.equals("Zl")){
				     System.out.print("E: ");                                                
				     String str=br.readLine();
				     double x=Double.parseDouble(str);     
				     String value = String.format("%.2f", x*KURS_E_Zl);
				     System.out.println("PLN: " + value);
	        	 }
	         }
	         
	         if (str1.equals("Zl"))
	        	 if (str2.equals("$")){
			         System.out.print("Zl: ");                                                
			         String str=br.readLine();
			         double x=Double.parseDouble(str);   
			         String value = String.format("%.2f", x/KURS_S_Zl);
			         System.out.println("$: "+value);
	        	 }
	        	 else if (str2.equals("E")){
				     System.out.print("Zl: ");                                                
				     String str=br.readLine();
				     double x=Double.parseDouble(str);     
				     String value = String.format("%.2f", x/KURS_E_Zl);
				     System.out.println("EURO: "+value);
	        	 }
	      }
	                                                                                 
	      catch(IOException e1)                                                      
	      {                                                                          
	         System.out.println("wyjatek operacji wejscia/wyjscia");                 
	      }                                                                          
	                                                                                 
	      catch(NumberFormatException e2)                                            
	      {                                                                          
	         System.err.println("nieprawidlowy format liczby");                      
	      }                                                                          
	   }             
}
