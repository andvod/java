package zadanie4;

import java.io.*;
import java.security.*;
import javax.crypto.*;

public class RSATest {

	public static void main(String args[]) throws Exception                                                        
	   {                                                                                                              
	      System.out.println("zaczyna rejestrowac provider");                                                         
	      Provider prov = new org.bouncycastle.jce.provider.BouncyCastleProvider();                                   
	      Security.addProvider(prov);                                                                                 
	                                                                                                                  
	      System.out.println("zaczyna generowac generator pary kluczy");                                              
	      KeyPairGenerator kpgen = KeyPairGenerator.getInstance("RSA","BC");                                          
	      kpgen.initialize(1024, new java.security.SecureRandom());                                                   
	                                                                                                                  
	      System.out.println("zaczyna generowac pare kluczy");                                                        
	      KeyPair pair = kpgen.genKeyPair();                                                                          
	                                                                                                                  
	      System.out.println("zaczyna generowac klucz prywatny");                                                     
	      PrivateKey priv = pair.getPrivate();                                                                        
	                                                                                                                  
	      System.out.println("zaczyna generowac klucz publiczny");                                                    
	      PublicKey pub = pair.getPublic();                                                                           
	                                                                                                                  
	                                                                                                                  
	                                                                                                                  
	      //-- CipherStream: szyfrowanie --                                                                           
	      System.out.println("zaczyna generowac cipher");                                                             
	      javax.crypto.Cipher c1 = javax.crypto.Cipher.getInstance("RSA/ECB/PKCS1Padding","BC");                      
	      c1.init(Cipher.ENCRYPT_MODE,pub);                                                                           
	                                                                                                                  
	      System.out.println("zaczyna zestawiac strumien wyjsciowy");                                                 
	      ObjectOutputStream out=new ObjectOutputStream(new CipherOutputStream(new FileOutputStream("plikSzyfrowany.txt"),c1)); 
	          
	      //-- Czyta z klawiatury --
	      BufferedReader br=new BufferedReader(new InputStreamReader(System.in));                    
          
	      String str = "";
	      try                                                                                        
	      {   
	    	 String strOnce;
	    	 for (;;){
		         System.out.print("Prosze wpisac notatki lub Koniec dla wyjscia: ");                                                             
		         strOnce = br.readLine(); 
		         if (strOnce.equalsIgnoreCase("Koniec")) break;
		         str += strOnce + "\n";
	    	 }
	      }                                                                                          
	      catch(Exception e){
	    	  System.out.println(e);}   
	      
	      System.out.println("zaczyna zapisywac obiekt do strumienia");                                               
	      out.writeObject(new String(str)); 
	      out.flush();                                                                                                
	      out.close(); 
 
	                                                                                                                                                                                                                                                                                                                       
	      //-- CipherStream: deszyfrowanie  --                                                                        
	      System.out.println("zaczyna generowac cipher");                                                             
	      javax.crypto.Cipher c2 = javax.crypto.Cipher.getInstance("RSA/ECB/PKCS1Padding","BC");                      
	      c2.init(Cipher.DECRYPT_MODE,priv);                                                                          
	                                                                                                                  
	      System.out.println("zaczyna zestawiac strumien wejsciowy");                                                 
	      ObjectInputStream in=new ObjectInputStream(new CipherInputStream(new FileInputStream("plikSzyfrowany.txt"),c2));      
	                                                                                                                  
	      System.out.println("zaczyna czytac obiekt ze strumienia"); 
	      String strRead=(String)in.readObject();                                                                         
                                                                                                           
		  System.out.println("\n--\n"+strRead+" \n--\n");

	      in.close(); 	                      
	   }                   

}
