package zadanie3;

import java.io.*;

public class Prostokat {
	
	double a, b;
	String name;
	
	public Prostokat(String name, double a, double b){
		this.a = a;
		this.b = b;
		this.name = name;
	}
	
	public Prostokat(String name){
		this.name = name;
	}
	
	public void save(){
	      try                                                                                        
	      {                                                                                                                                                                                                                                          
	         PrintWriter plik1=new PrintWriter(new BufferedWriter(new FileWriter(this.name,true))); 
	         plik1.println(this.name);
	         plik1.println("strona a = " + this.a);
	         plik1.println("strona b = " + this.b); 
	         plik1.println("\n");
	         plik1.close(); 
	         System.out.println("Ok");
	      }                                                                                          
	      catch(Exception e){System.out.println(e);}  
	}
	
	public void watch(){
		
		System.out.println("\n-- z pliku --");                                                     
        
	    try                                                                                        
	    {                                                                                          
	         BufferedReader plik2=new BufferedReader(new FileReader(this.name));                    
	         String str;                                                                             
	                                                                                                 
	         while(plik2.ready())                                                                    
	         {                                                                                       
	            str=plik2.readLine();                                                                
	            System.out.println(str);                                                             
	         }                                                                                       
	                                                                                                 
	         plik2.close();                                                                          
	   }                                                                                          
	   catch(Exception e){System.out.println(e);}                                                 
	}    
	
	public static void main(String args[]){
		Prostokat obj1 = new Prostokat("plikProst.txt", 4, 5);
		obj1.save();
		
		Prostokat obj2 = new Prostokat("plikProst.txt");
		obj2.watch();
	}
}
