package localhost;

import java.io.*;
import java.net.*;

public class Serwer extends Thread {
	
	public int PORT = 50007;
	
	public Serwer(int port){
		this.PORT = port;
	}

	public void run() {
        ServerSocket serv;
        try {
            serv = new ServerSocket(PORT);

            Socket sock = serv.accept();
            System.out.println(sock);

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(sock.getInputStream()));
            
            new Wydanie(sock).start();
            
            String line = null;
            while ((line = in.readLine()) != null) {
                System.out.println("<Nadeszlo Serwer:> " + line);
                if (line.equalsIgnoreCase("end")){
                	break;
                }
            }
            serv.close();
            System.out.println("koniec polaczenia z klientem");

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
