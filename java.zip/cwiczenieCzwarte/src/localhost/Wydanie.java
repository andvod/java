package localhost;

import java.io.*;
import java.net.*;

class Wydanie extends Thread
{
	Socket sock;
	BufferedReader sockReader;
	PrintWriter out;
   
   public Wydanie(Socket sock) throws IOException                                         
   {                                                                                    
      this.sock=sock;                                                                   
      this.sockReader=new BufferedReader(new InputStreamReader(System.in)); 
      this.out = new PrintWriter(new OutputStreamWriter(sock.getOutputStream()));
   }                                                                                    
   
   public void run() 
   {      
	      try {                                                                                                                 
	    	  String str = "";
	    		while (!str.equalsIgnoreCase("Koniec")){
	    			System.out.print("<Wysylamy Server:> ");                                                
	    			str=sockReader.readLine();                                                      
	    			out.println(str);                                                               
	    			out.flush(); 
	    			
	    			Thread.sleep(200);
	    		}
	    		      
	    		System.out.println("Koniec polaczenia");
		      
		      //zamykanie polaczenia                                                 
		      sockReader.close();                                                           
		      sock.close(); 
		      out.close();
	      }
	      catch(IOException e){
	    	  System.out.println("Error");
	        } catch (InterruptedException e){
	        	e.printStackTrace();
	        }
   }                 
}