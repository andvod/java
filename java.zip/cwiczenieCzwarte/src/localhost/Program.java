package localhost;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int port = 50007;
		
		Serwer serv = new Serwer(port);
		Klient sock = new Klient(port);
		serv.start();
		sock.start();
	}

}
