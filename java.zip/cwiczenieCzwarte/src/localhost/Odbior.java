package localhost;

import java.io.*;
import java.net.*;

class Odbior extends Thread
{
   Socket sock;
   BufferedReader sockReader;
   
   public Odbior(Socket sock) throws IOException                                         
   {                                                                                    
      this.sock=sock;                                                                   
      this.sockReader=new BufferedReader(new InputStreamReader(sock.getInputStream())); 
   }                                                                                    
   
   public void run() 
   {      
	      try {                                                                                                                 
		      //komunikacja - czytanie danych ze strumienia 
		      for(;;)
		      {
			      String str;                                                            
			      str=sockReader.readLine();    
			      if(str.equals("Koniec")) break;
			      System.out.println("<Nadeszlo Klient:> " + str);  
		      }
		      
		      System.out.println("Koniec polaczenia");
		      
		      //zamykanie polaczenia                                                 
		      sockReader.close();                                                           
		      sock.close(); 
	      }
	      catch(IOException e)
	      {
	    	  System.out.println("Error");
	      }
   }                 
}