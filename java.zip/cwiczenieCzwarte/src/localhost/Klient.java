package localhost;

import java.io.*;
import java.net.*;

public class Klient extends Thread {
	
	public int PORT = 50007;
	public String IP = "localhost";
	
	public Klient(int port, String ip){
		this.PORT = port;
		this.IP = ip;
	}
	
	public Klient(int port){
		this.PORT = port;
	}
	
	public Klient(String ip){
		this.IP = ip;
	}
	
	public void run(){
		try {
            Socket sock = new Socket(IP, PORT);
            
            PrintWriter out = new PrintWriter(
                    new OutputStreamWriter(sock.getOutputStream()));
            
            BufferedReader klaw;                                                             
  		    klaw=new BufferedReader(new InputStreamReader(System.in)); 
  		    
  		    //tworzenie watka odbierajacego                        
  		    new Odbior(sock).start();

      		String str = "";
    		while (!str.equalsIgnoreCase("Koniec")){
    			System.out.print("<Wysylamy Klient:> ");                                                
    			str=klaw.readLine();                                                      
    			out.println(str);                                                               
    			out.flush(); 
    			
    			Thread.sleep(200);
    		}
    		      
    		System.out.println("Koniec polaczenia");
    		                                                                                       
    		//zamykanie polaczenia                                                           
    		klaw.close();                                                                    
    		out.close();                                                                    
    		sock.close(); 
        } catch (InterruptedException e){
        	e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace(); 
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}

	
