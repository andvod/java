package zadanie3;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class ObslugaZadania extends Thread{
	
	 Socket sock;
	 BufferedReader in;
	 ArrayList <Socket> connections;
	   
	   ObslugaZadania(Socket klientSocket, ArrayList <Socket> connections)  
	   {    
		  try {
		      this.sock=klientSocket; 
		      this.connections = connections;
		      this.in = new BufferedReader(
		    		  new InputStreamReader(this.sock.getInputStream()));
	      }
	      catch (IOException e){
	    	  System.out.println(e);
	      }
	   }  
	   
	   public void run(){    
	        try {                                 
	        	String line = null;
                while ((line = in.readLine()) != null) {
                	for(Socket s : connections) { 
                		if (s == this.sock) continue;
                		PrintWriter out = new PrintWriter(
          		      			new OutputStreamWriter(s.getOutputStream()));
    	                out.println(line); 
    	                out.flush();
                	}
                	
                    if (line.equalsIgnoreCase("Koniec")){
                    	break;
                    }
                }
                System.out.println("Koniec polacznia z " + sock);
	                                               
	        } catch (IOException e) { 
	            e.printStackTrace(); 
	        } 
	   }
}
