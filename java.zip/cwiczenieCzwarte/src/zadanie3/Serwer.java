package zadanie3;

import java.io.*;
import java.net.*;
import java.util.ArrayList;

public class Serwer {
	
	public static void main(String[] args) throws IOException     
	   {       
			try{
		      ServerSocket serv = new ServerSocket(800);
		      ArrayList <Socket> connections = new <Socket> ArrayList();	  
		      
		      while(true)                                               
		      {                                                         
		         //przyjecie polaczenia                                 
		         System.out.println("Oczekiwanie na polaczenie...");    
		         Socket sock=serv.accept();  
		         
		         if(!connections.contains(sock)) connections.add(sock);
		         
		         if(connections.size() > 100){
		        	 System.out.println("Too many users");
		        	 break;
		         }
		         
		         //tworzenie watku obslugi tego polaczenia              
		         new ObslugaZadania(sock, connections).start();                      
		      }   
		      
		      serv.close();
			}
			catch (IOException e){
				System.out.println("Koniec polaczenia");
			}
	   }
}
