package zadanie2;

import java.io.*;
import java.net.*;

public class Klient
{
   public static final int PORT=50007;
   public static final String HOST = "155.158.133.187";
   
   public static void main(String[] args) throws IOException  
   {                                                         
      //nawiazanie polaczenia z serwerem                     
      Socket sock;                                           
      sock=new Socket(HOST,PORT);                            
      System.out.println("Nawiazalem polaczenie: "+sock);    
                                                             
      //tworzenie watka odbierajacego                        
      new Odbior(sock).start();                              
                                                             
      //================================
      BufferedReader klaw;                                                             
      klaw=new BufferedReader(new InputStreamReader(System.in));                       
      PrintWriter outp;                                                                
      outp=new PrintWriter(sock.getOutputStream());                                    
                                                                                       
      //komunikacja - czytanie danych z klawiatury i przekazywanie ich do strumienia 
      for(;;)
      {
	      System.out.print("<Wysylamy:> ");                                                
	      String str=klaw.readLine();   
	      if(str.equals("Koniec")) break;
	      outp.println(str);                                                               
	      outp.flush(); 
      }
                                                             
      //zamykanie polaczenia                                 
      sock.close();                                          
   }                                                         
}
