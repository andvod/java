package zadanie1;

import java.io.BufferedReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

public class SerwerKlientThread {

	public static void main(String[] args) throws IOException {
		System.out.println();
        startServer();
        startSender();
    }

    public static void startSender() {
        (new Thread() {
            @Override
            public void run() {
                try {
                    Socket s = new Socket("localhost", 60010);
                    PrintWriter out = new PrintWriter(
                            new OutputStreamWriter(s.getOutputStream()));
                    BufferedReader klaw;                                                             
          		    klaw=new BufferedReader(new InputStreamReader(System.in)); 
          		    

	          		String str = "";
	        		while (!str.equalsIgnoreCase("Koniec")){
	        			System.out.print("<Wysylamy:> ");                                                
	        			str=klaw.readLine();                                                      
	        			out.println(str);                                                               
	        			out.flush(); 
	        			
	        			Thread.sleep(200);
	        		}
	        		      
	        		System.out.println("Koniec polaczenia");
	        		                                                                                       
	        		//zamykanie polaczenia                                                           
	        		klaw.close();                                                                    
	        		out.close();                                                                    
	        		s.close(); 
                } catch (InterruptedException e){
                	e.printStackTrace();
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                    
                } catch (IOException e) {
                    e.printStackTrace();
                
                }
            }
        }).start();
    }

    public static void startServer() {
        (new Thread() {
            @Override
            public void run() {
                ServerSocket ss;
                System.out.println("init SERVER");
                try {
                    ss = new ServerSocket(60010);

                    Socket s = ss.accept();

                    BufferedReader in = new BufferedReader(
                            new InputStreamReader(s.getInputStream()));
                    String line = null;
                    while ((line = in.readLine()) != null) {
                        System.out.println("serwer: " + line);
                        if (line.equalsIgnoreCase("end")){
                        	break;
                        }
                    }
                    ss.close();
                    System.out.println("koniec polaczenia z klientem");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}