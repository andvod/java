package zadanie1;

import java.io.*;
import java.net.*;

public class Serwer
{
   public static final int PORT=50007;
   
   public static void main(String args[]) throws IOException                  
   {          
	  try{
	      //tworzenie gniazda serwerowego                                        
	      ServerSocket serv;                                                     
	      serv=new ServerSocket(PORT);                                           
	                                                                             
	      //oczekiwanie na polaczenie i tworzenie gniazda sieciowego             
	      System.out.println("Nasluchuje: "+serv);                               
	      Socket sock;                                                           
	      sock=serv.accept();                                                    
	      System.out.println("Jest polaczenie: "+sock);                          
	                                                                             
	      //tworzenie strumienia danych pobieranych z gniazda sieciowego         
	      BufferedReader inp;                                                    
	      inp=new BufferedReader(new InputStreamReader(sock.getInputStream()));  
	      
	      PrintWriter plik1=new PrintWriter(new BufferedWriter(new FileWriter("plik.txt",true)));
	                                                                             
	      //komunikacja - czytanie danych ze strumienia   
	      String line = null;
          while ((line = inp.readLine()) != null) {
              System.out.println("serwer: " + line);
              plik1.println(line);
              if (line.equalsIgnoreCase("Koniec")){
              	break;
              }
          }
	                                                                             
	      //zamykanie polaczenia                                                 
	      inp.close();                                                           
	      sock.close();                                                          
	      serv.close();
	      plik1.close();
	  }
	  catch (IOException e){
		  System.out.println("polaczenie zostalo przerwane");
	  }
   }                                                                         
}