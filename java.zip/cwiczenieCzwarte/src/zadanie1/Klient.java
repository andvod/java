package zadanie1;

import java.io.*;
import java.net.*;

public class Klient
{
   public static final int PORT=50007;
   public static final String HOST = "localhost";
   
   public static void main(String[] args) throws IOException                            
   {    
	  try{
		  //nawiazanie polaczenia z serwerem     
	      Socket sock;   
			  sock=new Socket(HOST,PORT); 
			  System.out.println("Nawiazalem polaczenie: "+sock); 
		                                                                                       
		  //tworzenie strumieni danych pobieranych z klawiatury i dostarczanych do socketu 
		  BufferedReader klaw;                                                             
		  klaw=new BufferedReader(new InputStreamReader(System.in));                       
		  PrintWriter outp; 
		  outp=new PrintWriter(sock.getOutputStream());  
		                                                                                       
		  //komunikacja - czytanie danych z klawiatury i przekazywanie ich do strumienia  
		  String str = "";
		  while (!str.equalsIgnoreCase("Koniec")){
			  System.out.print("<Wysylamy:> ");                                                
			  str=klaw.readLine();                                                      
			  outp.println(str);                                                               
			  outp.flush();   
		  }
		      
		  System.out.println("Koniec polaczenia");
		                                                                                       
		  //zamykanie polaczenia                                                           
		  klaw.close();                                                                    
		  outp.close();                                                                    
		  sock.close(); 
	  }
	  catch (java.net.SocketException e){
		  System.out.println(e);
	  }
      catch (IOException e){
    	  System.out.println("Polaczenie zostalo przerwane");
      }
   }                                                                                   
}
